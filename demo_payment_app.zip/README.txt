DEMO PAYMENT APP
1. Open index.html in a browser.
2. For the first unlock use the demo code supplied separately.
3. Demo PIN is supplied separately.
4. Transactions are stored locally in the browser.
This project does not connect to banks, UPI, wallets, or real payments.
